public class A {
    private static int k;
    private static int q = 12;
    private final double PI = 3.14;
    private static final int SIZE = 20;
    public void m1(){
        int x = 100;
        double d = 2.3;
        char ch = 'a';
        String text = "CS 320 Programming Language";
        if(ch == 'a'){
            int k = 10;
            boolean flag = true;
        }else{
            double f = 12f;
        }
        float f = 1.3f;
    }

}
